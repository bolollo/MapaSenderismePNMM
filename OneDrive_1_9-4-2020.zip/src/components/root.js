export default function createRoot() {
	return "<div id='map'></div>";
}
