
import App from './app';

App();