export default [
    {id:7,label:"Camins del Parc",layers:["camins-geojson-LineString",],visibility:false},
	{id:8,label:"Fonts",layers:["Font_B","Font_C_D","Font_CP","Font_DGT","Font_M","Font_R","Font_R_X"],visibility:false},
	{id:9,label:"Conjunt Eremític",layers:["Ermites","Capella"],visibility:false},
]
