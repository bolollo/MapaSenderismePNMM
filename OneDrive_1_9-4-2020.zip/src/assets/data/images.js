import mountain from "../images/mountain.png";
import no_entry from "../images/no_entry.png";
import parking from "../images/parking.png";
import park_bench from "../images/park_bench.png";
import Font_1 from "../images/Font_1.png";
import Font_2 from "../images/Font_2.png";
import Font_3 from "../images/Font_3.png";
import Font_4 from "../images/Font_4.png";
import Font_5 from "../images/Font_5.png";
import Font_6 from "../images/Font_6.png";
import Font_7 from "../images/Font_7.png";
import Ermita from "../images/Ermita.png";
import Capella from "../images/Capella.png";

export default {
	mountain: mountain,
	no_entry: no_entry,
	parking: parking,
	park_bench: park_bench,
    Font_1: Font_1,
    Font_2: Font_2,
    Font_3: Font_3,
    Font_4: Font_4,
    Font_5: Font_5,
    Font_6: Font_6,
    Font_7: Font_7,
    Ermita: Ermita,
    Capella: Capella,
}