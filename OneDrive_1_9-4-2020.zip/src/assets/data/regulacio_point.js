export default {
"type": "FeatureCollection",
"name": "Regulacio_Point",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Codi": "G", "Nom": "Canal dels Arínjols", "Regulacio": "Canal temporalment tancada", "atr": "G", "file": "http:\/\/muntanyamontserrat.gencat.cat\/ca\/actualitat\/detalls\/Noticia\/Tancament_CanalArinjols", "image": "http:\/\/www.gencat.cat\/patronatmontserrat\/escalada\/images\/Arinjols.png" }, "geometry": { "type": "Point", "coordinates": [ 1.819713940796475, 41.6034931396659 ] } },
]
}
